# DOS Project 2 - Gossip simulator

## How to run
```
mix escript.build
./proj2 <numNodes> <topology> <algorithm>
```